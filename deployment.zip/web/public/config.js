window.config = {
  userPoolId: 'us-east-2_2NKnlyBUD',
  clientId: '19suqo5qbcfc1g37ud2puj7rqr',
  apiEndpoint: 'https://8i4x6xxit5.execute-api.us-east-2.amazonaws.com/prod/'
};
